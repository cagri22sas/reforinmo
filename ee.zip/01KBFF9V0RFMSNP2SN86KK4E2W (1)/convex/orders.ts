import { v, ConvexError } from "convex/values";
import { mutation, query, internalMutation, internalQuery } from "./_generated/server";
import { getCurrentUser } from "./helpers";

export const create = mutation({
  args: {
    shippingMethodId: v.id("shippingMethods"),
    shippingAddress: v.object({
      name: v.string(),
      street: v.string(),
      city: v.string(),
      state: v.string(),
      zipCode: v.string(),
      country: v.string(),
      phone: v.string(),
    }),
    notes: v.optional(v.string()),
    guestEmail: v.optional(v.string()),
    sessionId: v.optional(v.string()),
    couponCode: v.optional(v.string()),
    discount: v.optional(v.number()),
    couponId: v.optional(v.id("coupons")),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    
    let userId = undefined;
    let guestEmail = undefined;
    let sessionId = undefined;
    
    if (identity) {
      // Authenticated user
      const user = await ctx.db
        .query("users")
        .withIndex("by_token", (q) =>
          q.eq("tokenIdentifier", identity.tokenIdentifier),
        )
        .unique();
      
      if (!user) {
        throw new ConvexError({
          message: "User not found",
          code: "NOT_FOUND",
        });
      }
      userId = user._id;
    } else {
      // Guest user
      if (!args.guestEmail) {
        throw new ConvexError({
          message: "Email required for guest checkout",
          code: "BAD_REQUEST",
        });
      }
      guestEmail = args.guestEmail;
      sessionId = args.sessionId;
    }

    // Get cart items
    let cartItems;
    if (userId) {
      cartItems = await ctx.db
        .query("cart")
        .withIndex("by_user", (q) => q.eq("userId", userId))
        .collect();
    } else if (sessionId) {
      cartItems = await ctx.db
        .query("cart")
        .withIndex("by_session", (q) => q.eq("sessionId", sessionId))
        .collect();
    } else {
      throw new ConvexError({
        message: "No cart found",
        code: "NOT_FOUND",
      });
    }

    if (cartItems.length === 0) {
      throw new ConvexError({
        message: "Cart is empty",
        code: "BAD_REQUEST",
      });
    }

    // Get shipping method
    const shippingMethod = await ctx.db.get(args.shippingMethodId);
    if (!shippingMethod || !shippingMethod.active) {
      throw new ConvexError({
        message: "Invalid shipping method",
        code: "BAD_REQUEST",
      });
    }

    // Calculate totals and validate products
    let subtotal = 0;
    const items = [];
    const validCartItemIds = [];

    for (const cartItem of cartItems) {
      const product = await ctx.db.get(cartItem.productId);
      
      // Skip invalid or inactive products, but delete them from cart
      if (!product || !product.active) {
        await ctx.db.delete(cartItem._id);
        continue;
      }

      if (product.stock < cartItem.quantity) {
        throw new ConvexError({
          message: `Not enough stock for: ${product.name}. Available: ${product.stock}, Requested: ${cartItem.quantity}`,
          code: "BAD_REQUEST",
        });
      }

      // Get first image URL
      let imageUrl = null;
      if (product.images && product.images.length > 0) {
        imageUrl = product.images[0];
      } else if (product.imageStorageIds && product.imageStorageIds.length > 0) {
        imageUrl = await ctx.storage.getUrl(product.imageStorageIds[0]);
      }

      subtotal += product.price * cartItem.quantity;
      items.push({
        productId: product._id,
        productName: product.name,
        productImage: imageUrl || "",
        quantity: cartItem.quantity,
        price: product.price,
      });
      
      // Track valid cart items to delete later
      validCartItemIds.push(cartItem._id);
    }

    // If all items were invalid, throw error
    if (items.length === 0) {
      throw new ConvexError({
        message: "All cart items are invalid. Please add products to your cart.",
        code: "BAD_REQUEST",
      });
    }

    const shippingCost = shippingMethod.price;
    const discount = args.discount || 0;
    const total = subtotal + shippingCost - discount;

    // Generate secure, unpredictable order number
    const timestamp = Date.now().toString(36).toUpperCase();
    const randomPart = Math.random().toString(36).substring(2, 12).toUpperCase();
    const orderNumber = `ORD-${timestamp}${randomPart}`;

    // Create order
    const orderId = await ctx.db.insert("orders", {
      userId,
      guestEmail,
      guestSessionId: sessionId,
      orderNumber,
      status: "pending",
      subtotal,
      shippingCost,
      discount: discount > 0 ? discount : undefined,
      couponCode: args.couponCode,
      total,
      shippingMethodId: args.shippingMethodId,
      shippingAddress: args.shippingAddress,
      notes: args.notes,
    });

    // Increment coupon usage if applied
    if (args.couponId) {
      const coupon = await ctx.db.get(args.couponId);
      if (coupon) {
        await ctx.db.patch(args.couponId, {
          usageCount: coupon.usageCount + 1,
        });
      }
    }

    // Create order items
    for (const item of items) {
      await ctx.db.insert("orderItems", {
        orderId,
        ...item,
      });
    }

    // DO NOT clear cart here - cart will be cleared after successful payment
    // This prevents the checkout page from unmounting Stripe Elements during payment

    return orderId;
  },
});

export const list = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);

    const orders = await ctx.db
      .query("orders")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .collect();

    return orders;
  },
});

export const get = query({
  args: { orderId: v.id("orders") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);

    const order = await ctx.db.get(args.orderId);
    if (!order || order.userId !== user._id) {
      throw new Error("Order not found");
    }

    const items = await ctx.db
      .query("orderItems")
      .withIndex("by_order", (q) => q.eq("orderId", args.orderId))
      .collect();

    const shippingMethod = await ctx.db.get(order.shippingMethodId);

    return {
      ...order,
      items,
      shippingMethod,
    };
  },
});

export const trackOrder = query({
  args: {
    orderNumber: v.string(),
    email: v.string(),
  },
  handler: async (ctx, args) => {
    const order = await ctx.db
      .query("orders")
      .withIndex("by_order_number", (q) => q.eq("orderNumber", args.orderNumber))
      .unique();

    if (!order) {
      throw new ConvexError({
        message: "Order not found",
        code: "NOT_FOUND",
      });
    }

    // Verify email matches
    const emailLower = args.email.toLowerCase();
    const orderEmail = order.guestEmail?.toLowerCase();
    
    // For authenticated users, check the user's email
    if (order.userId) {
      const user = await ctx.db.get(order.userId);
      if (user && user.email?.toLowerCase() !== emailLower) {
        throw new ConvexError({
          message: "Email does not match order",
          code: "FORBIDDEN",
        });
      }
    } else if (orderEmail !== emailLower) {
      // For guest orders, check guest email
      throw new ConvexError({
        message: "Email does not match order",
        code: "FORBIDDEN",
      });
    }

    const items = await ctx.db
      .query("orderItems")
      .withIndex("by_order", (q) => q.eq("orderId", order._id))
      .collect();

    const shippingMethod = await ctx.db.get(order.shippingMethodId);

    return {
      ...order,
      items,
      shippingMethod,
    };
  },
});

// Internal queries and mutations for Stripe
export const getById = internalQuery({
  args: { orderId: v.id("orders") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.orderId);
  },
});

export const getOrderForCheckout = internalQuery({
  args: { orderId: v.id("orders") },
  handler: async (ctx, args) => {
    const order = await ctx.db.get(args.orderId);
    if (!order) {
      return null;
    }

    const items = await ctx.db
      .query("orderItems")
      .withIndex("by_order", (q) => q.eq("orderId", args.orderId))
      .collect();

    const shippingMethod = await ctx.db.get(order.shippingMethodId);
    const user = order.userId ? await ctx.db.get(order.userId) : null;

    return {
      ...order,
      items,
      shippingMethod,
      user,
    };
  },
});

export const updatePaymentIntent = internalMutation({
  args: {
    orderId: v.id("orders"),
    paymentIntentId: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.orderId, {
      stripePaymentIntentId: args.paymentIntentId,
    });
  },
});

export const handleSuccessfulPayment = internalMutation({
  args: {
    orderId: v.string(),
    paymentIntentId: v.string(),
  },
  handler: async (ctx, args) => {
    // orderId comes from Stripe metadata and is a Convex ID
    // Try to get it from orders table
    const orders = await ctx.db.query("orders").collect();
    const order = orders.find(o => o._id === args.orderId);

    if (!order) {
      console.error("Order not found:", args.orderId);
      return;
    }

    // Idempotency: prevent double processing
    if (order.status !== "pending") {
      console.log("Order already processed:", args.orderId, "Status:", order.status);
      return;
    }

    // Get order items
    const items = await ctx.db
      .query("orderItems")
      .withIndex("by_order", (q) => q.eq("orderId", order._id))
      .collect();

    // Re-validate stock before processing payment
    for (const item of items) {
      const product = await ctx.db.get(item.productId);
      if (!product) {
        console.error("Product not found during payment:", item.productId);
        // Cancel order due to missing product
        await ctx.db.patch(order._id, {
          status: "cancelled",
          notes: "Product no longer available",
        });
        return;
      }
      
      if (product.stock < item.quantity) {
        console.error("Insufficient stock during payment:", item.productId);
        // Cancel order due to insufficient stock
        await ctx.db.patch(order._id, {
          status: "cancelled",
          notes: `Insufficient stock for ${product.name}`,
        });
        return;
      }
    }

    // Update order status
    await ctx.db.patch(order._id, {
      status: "processing",
      stripePaymentIntentId: args.paymentIntentId,
    });

    // Reduce stock for each item
    for (const item of items) {
      const product = await ctx.db.get(item.productId);
      if (product) {
        await ctx.db.patch(item.productId, {
          stock: Math.max(0, product.stock - item.quantity),
        });
      }
    }

    // Clear cart after successful payment
    if (order.userId) {
      // Clear cart for authenticated user
      const cartItems = await ctx.db
        .query("cart")
        .withIndex("by_user", (q) => q.eq("userId", order.userId!))
        .collect();
      for (const cartItem of cartItems) {
        await ctx.db.delete(cartItem._id);
      }
    } else if (order.guestSessionId) {
      // Clear cart for guest user
      const cartItems = await ctx.db
        .query("cart")
        .withIndex("by_session", (q) => q.eq("sessionId", order.guestSessionId!))
        .collect();
      for (const cartItem of cartItems) {
        await ctx.db.delete(cartItem._id);
      }
    }
  },
});

export const handleFailedPayment = internalMutation({
  args: {
    paymentIntentId: v.string(),
  },
  handler: async (ctx, args) => {
    // Find order with this payment intent
    const orders = await ctx.db.query("orders").collect();
    const order = orders.find(
      (o) => o.stripePaymentIntentId === args.paymentIntentId,
    );

    if (order) {
      await ctx.db.patch(order._id, {
        status: "cancelled",
      });
    }
  },
});
